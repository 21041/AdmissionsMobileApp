// // src/api/client.js
// import axios from 'axios';
// import {API_BASE_URL} from './config';
// import AsyncStorage from '@react-native-async-storage/async-storage';

// const client = axios.create({baseURL: API_BASE_URL});

// // Example interceptor for future JWT (not yet used for dev route)
// client.interceptors.request.use(async cfg => {
//   const token = await AsyncStorage.getItem('jwtToken');
//   if (token) cfg.headers.Authorization = `Bearer ${token}`;
//   return cfg;
// });

// export default {
//   get: path => client.get(path).then(res => res.data),
//   post: (path, body) => client.post(path, body).then(res => res.data),
//   put: (path, body) => client.put(path, body).then(res => res.data),
//   delete: path => client.delete(path).then(res => res.data),
// };
