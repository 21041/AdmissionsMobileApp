// // src/api/config.js
// import {Platform} from 'react-native';

// // On Android emulator:
// export const API_BASE_URL = 'http://192.168.1.222:3000/api';

// // ── Make sure this matches your server exactly: ──
// export const SECRET_KEY = 'archdemo123';
