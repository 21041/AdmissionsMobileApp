// // src/context/AuthContext.tsx
// import React, {createContext, useState, useEffect, ReactNode} from 'react';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import apiClient from '../api/client';
// const CryptoJS = require('crypto-js');

// // ── Use the exact same SECRET_KEY from your server’s .env ──
// const SECRET_KEY = 'archdemo123';

// export type AuthContextType = {
//   isAuthenticated: boolean;
//   requestOtp: (email: string) => Promise<void>;
//   verifyOtp: (email: string, otp: string) => Promise<void>;
//   logout: () => Promise<void>;
// };

// export const AuthContext = createContext<AuthContextType | null>(null);

// interface AuthProviderProps {
//   children: ReactNode;
// }

// // Pad or truncate the key to 32 characters for AES-256
// const adjustKeyLength = (key: string, length = 32) =>
//   key.length > length ? key.slice(0, length) : key.padEnd(length, '0');

// // Turn any JS object into the `encryptedRequest` string your server decrypts
// const encryptPayload = (payload: object): string => {
//   const keyStr = adjustKeyLength(SECRET_KEY);
//   const key = CryptoJS.enc.Utf8.parse(keyStr);

//   const ciphertext = CryptoJS.AES.encrypt(JSON.stringify(payload), key, {
//     mode: CryptoJS.mode.ECB,
//     padding: CryptoJS.pad.Pkcs7,
//   }).toString();

//   // Debug: inspect the exact encryptedRequest you’re sending
//   console.log('🔐 encryptedRequest:', ciphertext);
//   return ciphertext;
// };

// export const AuthProvider: React.FC<AuthProviderProps> = ({children}) => {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);

//   // On mount, restore existing token if any
//   useEffect(() => {
//     AsyncStorage.getItem('jwtToken').then(token => {
//       setIsAuthenticated(!!token);
//     });
//   }, []);

//   // STEP 1: send OTP request
//   const requestOtp = async (email: string) => {
//     const encryptedRequest = encryptPayload({
//       users_email: email,
//       device_name: 'RN',
//       os_version: '1.0',
//     });
//     await apiClient.post('/login?version=1.0&step=1', {encryptedRequest});
//   };

//   // STEP 2: verify OTP and store JWT
//   const verifyOtp = async (email: string, otp: string) => {
//     const encryptedRequest = encryptPayload({
//       users_email: email,
//       otp,
//       device_name: 'RN',
//       os_version: '1.0',
//     });
//     const data = await apiClient.post('/login?version=1.0&step=2', {
//       encryptedRequest,
//     });
//     const token = data.otpVerif?.token;
//     if (!token) throw new Error('No token returned from server');
//     await AsyncStorage.setItem('jwtToken', token);
//     setIsAuthenticated(true);
//   };

//   const logout = async () => {
//     await AsyncStorage.removeItem('jwtToken');
//     setIsAuthenticated(false);
//   };

//   return (
//     <AuthContext.Provider
//       value={{isAuthenticated, requestOtp, verifyOtp, logout}}>
//       {children}
//     </AuthContext.Provider>
//   );
// };
